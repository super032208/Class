
<a href="view.php">View Project</a>&nbsp;&nbsp;&nbsp;
<a style="margin:2%;" href="iindex.php">Add Project</a>
<a style="margin:2%;" href="delete.php">Delete Project</a>
<a style="margin:2%;" href="update.php">Update Project</a>
<a style="margin:2%;" href="index.php"> Home </a>
<link rel="stylesheet" type="text/css" href="https://bootswatch.com/4/darkly/bootstrap.min.css">
