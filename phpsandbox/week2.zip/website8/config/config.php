<?php
define('ROOT_URL', 'http://localhost/phpsandbox/website8/');

define('DB_HOST', 'mysql:host=ict.neit.edu;port=5500;dbname=se266_hector;');
define('DB_USER', 'se266_hector');
define('DB_PASS', '8001596');
define ('DB_NAME', 'actores')

?>
