

<?php

    header('Location: upload.php');
?>
