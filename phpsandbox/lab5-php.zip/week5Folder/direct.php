<?php

    header('Location: search.php');
?>
