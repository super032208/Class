<?php

    $str = "Duck";

     echo sha1($str);
    echo "<br />";

     echo "e30bb6b05bdfacd363df4def6919184ace845d01";
 ?>
