<?php
    // Start the session
    session_start();
?>

<!DOCTYPE html>
<html>
<body>

    <h1><?php echo $_SESSION["login"]; ?></h1>

</body>
</html>
