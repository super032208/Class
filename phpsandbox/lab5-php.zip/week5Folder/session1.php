<?php
    // Start the session
    session_start();
?>

<!DOCTYPE html>
<html>
<body>

<?php
    // Set session variables
  //  $_SESSION[""] = "Mickey Mouse";
    $_SERVER['REQUEST_METHOD'] == 'POST';

?>
    <a href="login.php"></a>

</body>
</html>
